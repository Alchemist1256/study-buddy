import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CalendarDays, Clock, MoreHorizontal, Plus } from "lucide-react";
import { motion } from "framer-motion";
import softBg from "@assets/generated_images/soft_abstract_sage_green_paper_texture_background.png";
import { cn } from "@/lib/utils";

export default function Dashboard() {
  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <div className="relative rounded-3xl overflow-hidden shadow-lg group">
        <div className="absolute inset-0 z-0">
          <img 
            src={softBg} 
            alt="Background" 
            className="w-full h-full object-cover opacity-80"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-background/90 via-background/60 to-transparent" />
        </div>
        
        <div className="relative z-10 p-10 flex flex-col justify-center min-h-[240px]">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="font-serif text-4xl md:text-5xl font-bold text-foreground mb-4">
              Good morning, Alex.
            </h1>
            <p className="text-muted-foreground text-lg max-w-xl">
              You have <span className="text-primary font-semibold">3 upcoming exams</span> and <span className="text-primary font-semibold">5 tasks</span> due this week. Let's stay focused.
            </p>
            <div className="mt-8 flex gap-4">
              <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 shadow-md">
                <Plus className="mr-2 h-4 w-4" /> New Note
              </Button>
              <Button variant="outline" size="lg" className="bg-background/50 backdrop-blur-sm hover:bg-background/80">
                View Schedule
              </Button>
            </div>
          </motion.div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Recent Notes */}
        <div className="md:col-span-2 space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="font-serif text-2xl font-semibold text-foreground">Recent Notes</h2>
            <Button variant="ghost" className="text-muted-foreground hover:text-foreground">View All</Button>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {[1, 2, 3, 4].map((i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                whileHover={{ y: -4, transition: { duration: 0.2 } }}
              >
                <Card className="hover:shadow-lg transition-shadow duration-300 border-border/50 bg-card/50 backdrop-blur-sm cursor-pointer h-full">
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary mb-3">
                        <span className="font-serif font-bold text-lg">H</span>
                      </div>
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </div>
                    <CardTitle className="font-serif text-lg">History of Art: Renaissance</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground line-clamp-3 mb-4">
                      The Renaissance was a fervent period of European cultural, artistic, political and economic “rebirth” following the Middle Ages. Generally described as taking place from the 14th century...
                    </p>
                    <div className="flex items-center text-xs text-muted-foreground gap-2">
                      <Clock className="h-3 w-3" />
                      <span>Edited 2 hours ago</span>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Sidebar Widgets */}
        <div className="space-y-6">
          <h2 className="font-serif text-2xl font-semibold text-foreground">Overview</h2>
          
          <Card className="bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20 shadow-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <CalendarDays className="h-5 w-5 text-primary" />
                <span>Today's Plan</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {["Review Biology Ch. 4", "History Essay Draft", "Math Problem Set 3"].map((task, i) => (
                <div key={i} className="flex items-center gap-3 group">
                  <div className="h-5 w-5 rounded border border-primary/30 flex items-center justify-center group-hover:border-primary transition-colors cursor-pointer">
                    {i === 0 && <div className="h-3 w-3 bg-primary rounded-sm" />}
                  </div>
                  <span className={cn("text-sm", i === 0 ? "text-muted-foreground line-through" : "text-foreground")}>
                    {task}
                  </span>
                </div>
              ))}
              <Button variant="link" className="text-primary p-0 h-auto text-sm mt-2">
                + Add Task
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-card shadow-sm border-border/50">
            <CardHeader>
              <CardTitle className="text-lg">Study Streak</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-end justify-between h-24 gap-2">
                {[40, 60, 30, 80, 50, 90, 70].map((h, i) => (
                  <div key={i} className="flex-1 flex flex-col items-center gap-2 group">
                    <motion.div 
                      className="w-full bg-primary/20 rounded-t-sm group-hover:bg-primary/40 transition-colors relative"
                      initial={{ height: 0 }}
                      animate={{ height: `${h}%` }}
                      transition={{ delay: 0.2 + (i * 0.1), duration: 0.8, type: "spring" }}
                    >
                      {i === 5 && (
                         <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-foreground text-background text-[10px] px-2 py-1 rounded shadow-sm whitespace-nowrap">
                           Best day!
                         </div>
                      )}
                    </motion.div>
                    <span className="text-[10px] text-muted-foreground font-mono">
                      {["M", "T", "W", "T", "F", "S", "S"][i]}
                    </span>
                  </div>
                ))}
              </div>
              <div className="mt-4 text-center">
                <p className="text-2xl font-bold font-serif text-primary">12 Days</p>
                <p className="text-xs text-muted-foreground">Keep it up!</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
