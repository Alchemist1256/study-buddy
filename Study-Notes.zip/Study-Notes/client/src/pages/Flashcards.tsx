import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { RotateCw, Check, X, ArrowRight, ArrowLeft } from "lucide-react";

const FLASHCARDS = [
  { id: 1, front: "What is the mitochondria?", back: "The powerhouse of the cell. Organelles that generate most of the chemical energy needed to power the cell's biochemical reactions." },
  { id: 2, front: "Define 'Osmosis'", back: "The movement of water molecules from a solution with a high concentration of water molecules to a solution with a lower concentration of water molecules, through a cell's partially permeable membrane." },
  { id: 3, front: "What is the function of Ribosomes?", back: "Ribosomes are the sites in a cell in which protein synthesis takes place." },
];

export default function Flashcards() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [progress, setProgress] = useState(33);

  const handleNext = () => {
    setIsFlipped(false);
    setTimeout(() => {
      setCurrentIndex((prev) => (prev + 1) % FLASHCARDS.length);
      setProgress(((currentIndex + 2) / FLASHCARDS.length) * 100);
    }, 200);
  };

  const handlePrev = () => {
    setIsFlipped(false);
    setTimeout(() => {
      setCurrentIndex((prev) => (prev - 1 + FLASHCARDS.length) % FLASHCARDS.length);
      setProgress(((currentIndex) / FLASHCARDS.length) * 100);
    }, 200);
  };

  const currentCard = FLASHCARDS[currentIndex];

  return (
    <div className="h-[calc(100vh-8rem)] flex flex-col items-center justify-center max-w-4xl mx-auto space-y-8">
      
      {/* Header Info */}
      <div className="w-full flex items-center justify-between">
        <div>
          <h2 className="font-serif text-3xl font-bold text-foreground">Biology 101</h2>
          <p className="text-muted-foreground">Deck: Cell Structure • 24 cards</p>
        </div>
        <div className="flex items-center gap-4 w-1/3">
          <span className="text-sm font-medium text-muted-foreground whitespace-nowrap">Progress</span>
          <Progress value={progress} className="h-2" />
          <span className="text-sm font-medium text-primary">{Math.round(progress)}%</span>
        </div>
      </div>

      {/* Flashcard Area */}
      <div className="relative w-full max-w-2xl aspect-[3/2] perspective-1000">
        <motion.div
          className="w-full h-full relative preserve-3d cursor-pointer"
          animate={{ rotateY: isFlipped ? 180 : 0 }}
          transition={{ duration: 0.6, type: "spring", stiffness: 260, damping: 20 }}
          onClick={() => setIsFlipped(!isFlipped)}
          style={{ transformStyle: "preserve-3d" }}
        >
          {/* Front */}
          <div className="absolute inset-0 backface-hidden bg-card rounded-3xl shadow-xl border border-border/50 flex flex-col items-center justify-center p-12 text-center group hover:border-primary/50 transition-colors">
            <span className="text-sm uppercase tracking-widest text-muted-foreground font-semibold mb-6">Question</span>
            <h3 className="font-serif text-3xl md:text-4xl leading-tight text-foreground">
              {currentCard.front}
            </h3>
            <div className="absolute bottom-8 text-sm text-muted-foreground/50 opacity-0 group-hover:opacity-100 transition-opacity">
              Click to flip
            </div>
          </div>

          {/* Back */}
          <div 
            className="absolute inset-0 backface-hidden bg-primary text-primary-foreground rounded-3xl shadow-xl flex flex-col items-center justify-center p-12 text-center"
            style={{ transform: "rotateY(180deg)" }}
          >
            <span className="text-sm uppercase tracking-widest text-primary-foreground/60 font-semibold mb-6">Answer</span>
            <p className="font-serif text-2xl md:text-3xl leading-relaxed">
              {currentCard.back}
            </p>
          </div>
        </motion.div>
      </div>

      {/* Controls */}
      <div className="flex items-center gap-6">
        <Button variant="outline" size="icon" onClick={handlePrev} className="rounded-full h-12 w-12 border-2">
          <ArrowLeft className="h-5 w-5" />
        </Button>
        
        <div className="flex gap-4">
          <Button 
            className="rounded-full px-8 h-12 bg-destructive/10 text-destructive hover:bg-destructive/20 hover:text-destructive border-transparent shadow-none"
            variant="outline"
            onClick={handleNext}
          >
            <X className="mr-2 h-4 w-4" /> Hard
          </Button>
           <Button 
            className="rounded-full px-8 h-12 bg-secondary text-secondary-foreground hover:bg-secondary/80 border-transparent shadow-none"
            variant="outline"
            onClick={handleNext}
          >
            Good
          </Button>
          <Button 
            className="rounded-full px-8 h-12 bg-primary/10 text-primary hover:bg-primary/20 border-transparent shadow-none"
            variant="outline"
            onClick={handleNext}
          >
            <Check className="mr-2 h-4 w-4" /> Easy
          </Button>
        </div>

        <Button variant="outline" size="icon" onClick={handleNext} className="rounded-full h-12 w-12 border-2">
          <ArrowRight className="h-5 w-5" />
        </Button>
      </div>

    </div>
  );
}
