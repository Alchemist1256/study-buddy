import { useState } from "react";
import { Search, Plus, MoreVertical, FileText, Tag, Clock } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";

const NOTES_DATA = [
  {
    id: 1,
    title: "History of Art: Renaissance",
    preview: "The Renaissance was a fervent period of European cultural, artistic, political and economic “rebirth” following the Middle Ages. Generally described as taking place from the 14th century...",
    tags: ["History", "Art"],
    date: "2 hours ago",
    content: `
      <h1>History of Art: Renaissance</h1>
      <p>The Renaissance was a fervent period of European cultural, artistic, political and economic “rebirth” following the Middle Ages. Generally described as taking place from the 14th century to the 17th century, the Renaissance promoted the rediscovery of classical philosophy, literature and art.</p>
      
      <h2>Key Characteristics</h2>
      <ul>
        <li>Humanism</li>
        <li>Naturalism in Art</li>
        <li>Perspective and Depth</li>
        <li>Secularism</li>
      </ul>

      <h2>Major Artists</h2>
      <p>Leonardo da Vinci, Michelangelo, Raphael, Donatello...</p>
    `
  },
  {
    id: 2,
    title: "Molecular Biology: DNA Structure",
    preview: "DNA is a molecule composed of two polynucleotide chains that coil around each other to form a double helix carrying genetic instructions for the development, functioning, growth and reproduction of all known organisms...",
    tags: ["Biology", "Science"],
    date: "Yesterday",
    content: "..."
  },
  {
    id: 3,
    title: "Calculus: Derivatives",
    preview: "The derivative of a function of a real variable measures the sensitivity to change of the function value (output value) with respect to a change in its argument (input value). Derivatives are a fundamental tool of calculus...",
    tags: ["Math"],
    date: "3 days ago",
    content: "..."
  },
];

export default function Notes() {
  const [selectedNote, setSelectedNote] = useState(NOTES_DATA[0]);

  return (
    <div className="flex h-[calc(100vh-4rem)] rounded-2xl overflow-hidden shadow-2xl border border-border/50 bg-card">
      {/* Sidebar List */}
      <div className="w-80 border-r border-border bg-muted/30 flex flex-col">
        <div className="p-4 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-serif text-xl font-bold">Notes</h2>
            <Button size="icon" variant="ghost">
              <Plus className="h-5 w-5" />
            </Button>
          </div>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input 
              placeholder="Search notes..." 
              className="pl-9 bg-background border-transparent focus-visible:ring-1 focus-visible:ring-primary shadow-sm"
            />
          </div>
        </div>
        
        <ScrollArea className="flex-1">
          <div className="px-2 pb-4 space-y-1">
            {NOTES_DATA.map((note) => (
              <div 
                key={note.id}
                onClick={() => setSelectedNote(note)}
                className={`
                  p-3 rounded-lg cursor-pointer transition-all duration-200 group
                  ${selectedNote.id === note.id ? "bg-background shadow-md border border-border/50" : "hover:bg-background/50 hover:shadow-sm"}
                `}
              >
                <div className="flex justify-between items-start mb-1">
                  <h3 className={`font-medium text-sm line-clamp-1 ${selectedNote.id === note.id ? "text-primary" : "text-foreground"}`}>
                    {note.title}
                  </h3>
                  <span className="text-[10px] text-muted-foreground whitespace-nowrap ml-2">
                    {note.date}
                  </span>
                </div>
                <p className="text-xs text-muted-foreground line-clamp-2 mb-2 leading-relaxed">
                  {note.preview}
                </p>
                <div className="flex gap-1 flex-wrap">
                  {note.tags.map(tag => (
                    <span key={tag} className="text-[10px] px-1.5 py-0.5 bg-primary/5 text-primary rounded-full font-medium">
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </div>

      {/* Main Editor Area */}
      <div className="flex-1 flex flex-col bg-background relative">
        <div className="h-16 border-b border-border/50 flex items-center justify-between px-8 bg-background/50 backdrop-blur-sm sticky top-0 z-10">
           <div className="flex items-center gap-3 text-muted-foreground">
             <span className="text-xs uppercase tracking-widest font-medium">Last edited {selectedNote.date}</span>
             <Separator orientation="vertical" className="h-4" />
             <div className="flex gap-2">
                {selectedNote.tags.map(tag => (
                  <Badge key={tag} variant="secondary" className="text-xs font-normal bg-secondary text-secondary-foreground hover:bg-secondary/80">
                    {tag}
                  </Badge>
                ))}
             </div>
           </div>
           <div className="flex gap-2">
             <Button variant="ghost" size="sm">Share</Button>
             <Button variant="ghost" size="icon"><MoreVertical className="h-4 w-4" /></Button>
           </div>
        </div>

        <ScrollArea className="flex-1">
          <div className="max-w-3xl mx-auto py-12 px-8">
            <h1 className="font-serif text-4xl font-bold text-foreground mb-8 outline-none" contentEditable suppressContentEditableWarning>
              {selectedNote.title}
            </h1>
            <div 
              className="prose prose-lg prose-stone max-w-none font-serif text-foreground/80 leading-loose"
              dangerouslySetInnerHTML={{ __html: selectedNote.content }} 
            />
            {/* Mock Editor Placeholder */}
            <div className="mt-8 text-muted-foreground/50 italic font-mono text-sm">
              Press '/' for commands...
            </div>
          </div>
        </ScrollArea>
      </div>
    </div>
  );
}
