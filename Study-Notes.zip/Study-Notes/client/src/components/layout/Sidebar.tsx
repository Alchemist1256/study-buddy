import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { BookOpen, GraduationCap, LayoutDashboard, Library, Settings, Sparkles } from "lucide-react";
import { motion } from "framer-motion";

export function Sidebar() {
  const [location] = useLocation();

  const navItems = [
    { icon: LayoutDashboard, label: "Dashboard", href: "/" },
    { icon: BookOpen, label: "Notes", href: "/notes" },
    { icon: Library, label: "Flashcards", href: "/flashcards" },
  ];

  return (
    <div className="h-full w-full bg-sidebar text-sidebar-foreground flex flex-col">
      <div className="p-6 flex items-center gap-3">
        <div className="h-10 w-10 bg-primary/20 rounded-lg flex items-center justify-center">
          <GraduationCap className="h-6 w-6 text-primary-foreground" />
        </div>
        <span className="font-serif text-2xl font-semibold tracking-tight text-primary-foreground">Scholar</span>
      </div>

      <nav className="flex-1 px-4 py-6 space-y-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location === item.href;
          return (
            <Link key={item.href} href={item.href}>
              <a
                className={cn(
                  "flex items-center gap-3 px-4 py-3 rounded-md text-sm font-medium transition-all duration-200 group relative overflow-hidden z-10",
                  isActive
                    ? "text-sidebar-primary-foreground"
                    : "text-sidebar-foreground/70 hover:text-sidebar-accent-foreground"
                )}
              >
                {isActive && (
                  <motion.div
                    layoutId="sidebar-active"
                    className="absolute inset-0 bg-sidebar-primary shadow-md z-[-1]"
                    initial={false}
                    transition={{ type: "spring", stiffness: 300, damping: 30 }}
                  />
                )}
                
                <Icon className={cn("h-5 w-5 relative z-10", isActive ? "text-sidebar-primary-foreground" : "text-sidebar-foreground/60 group-hover:text-sidebar-accent-foreground")} />
                <span className="relative z-10">{item.label}</span>
                
                {isActive && (
                  <motion.div 
                    layoutId="sidebar-active-indicator"
                    className="absolute left-0 top-0 bottom-0 w-1 bg-primary rounded-r-full z-20" 
                  />
                )}
              </a>
            </Link>
          );
        })}
        
        <div className="pt-8 mt-8 border-t border-sidebar-border/50">
          <div className="px-4 text-xs font-medium text-sidebar-foreground/40 uppercase tracking-wider mb-2">
            AI Companion
          </div>
          <button className="w-full flex items-center gap-3 px-4 py-3 rounded-md text-sm font-medium text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground transition-all">
            <Sparkles className="h-5 w-5 text-amber-300" />
            Study Buddy
          </button>
        </div>
      </nav>

      <div className="p-4 border-t border-sidebar-border/50">
        <button className="flex items-center gap-3 w-full px-4 py-2 rounded-md hover:bg-sidebar-accent transition-colors text-sidebar-foreground/80">
          <Settings className="h-5 w-5" />
          <span className="text-sm font-medium">Settings</span>
        </button>
      </div>
    </div>
  );
}
